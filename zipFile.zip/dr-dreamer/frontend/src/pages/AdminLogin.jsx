import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../lib/api';

export default function AdminLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { token } = await api.login(email, password);
      localStorage.setItem('dd_token', token);
      navigate('/admin');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-page">
      <form className="login-card" onSubmit={handleSubmit}>
        <p className="eyebrow-sm">DR DREAMER</p>
        <h1 className="display login-title">Admin sign in</h1>

        {error && <p className="login-error">{error}</p>}

        <div className="field">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            autoFocus
          />
        </div>
        <div className="field">
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <button className="btn btn-primary login-btn" disabled={loading}>
          {loading ? 'Signing in…' : 'Sign in'}
        </button>
      </form>

      <style>{`
        .login-page {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--twilight);
          padding: 24px;
        }
        .login-card {
          background: var(--cream);
          border-radius: 20px;
          padding: 40px 34px;
          width: 100%;
          max-width: 380px;
          box-shadow: 0 24px 70px rgba(0,0,0,0.35);
        }
        .eyebrow-sm {
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.12em;
          color: var(--dusty-rose);
          margin: 0 0 8px;
        }
        .login-title { font-size: 26px; margin-bottom: 26px; }
        .login-error {
          background: #FBE7E9;
          color: #93303F;
          font-size: 13.5px;
          padding: 10px 14px;
          border-radius: 10px;
          margin-bottom: 18px;
        }
        .login-btn { width: 100%; margin-top: 6px; }
      `}</style>
    </div>
  );
}
