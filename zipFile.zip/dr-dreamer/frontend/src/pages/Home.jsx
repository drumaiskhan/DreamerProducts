import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import ProductCard from '../components/ProductCard';
import EnquiryModal from '../components/EnquiryModal';
import { api } from '../lib/api';

export default function Home() {
  const [filter, setFilter] = useState('all');
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [enquiryProduct, setEnquiryProduct] = useState(null);

  useEffect(() => {
    setLoading(true);
    setError('');
    api.getProducts(filter === 'all' ? null : filter)
      .then(setProducts)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [filter]);

  return (
    <div>
      <Navbar active={filter} onFilter={setFilter} />
      <Hero />

      <section id="shop" className="shop container">
        <h2 className="display shop-title">
          {filter === 'all' ? 'All products' : filter === 'skin' ? 'Skincare' : 'Haircare'}
        </h2>

        {loading && <p className="state-msg">Loading products…</p>}
        {error && <p className="state-msg">Couldn't load products: {error}</p>}
        {!loading && !error && products.length === 0 && (
          <p className="state-msg">No products here yet — check back soon.</p>
        )}

        <div className="grid">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} onEnquire={setEnquiryProduct} />
          ))}
        </div>
      </section>

      <footer className="footer">
        <div className="container footer-inner">
          <span className="display">Dr Dreamer</span>
          <p>Skin &amp; hair care, made to be part of the quiet moments in your day.</p>
          <Link to="/admin/login" className="admin-link">Admin</Link>
        </div>
      </footer>

      <EnquiryModal product={enquiryProduct} onClose={() => setEnquiryProduct(null)} />

      <style>{`
        .shop { padding: 20px 28px 90px; }
        .shop-title { font-size: 28px; margin-bottom: 28px; }
        .state-msg { color: var(--ink-soft); font-size: 15px; }
        .grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
          gap: 22px;
        }
        .footer {
          background: var(--twilight);
          color: rgba(250,243,236,0.85);
          padding: 44px 0;
          margin-top: 40px;
        }
        .footer-inner {
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          gap: 8px;
        }
        .footer-inner .display { font-size: 20px; color: var(--cream); }
        .footer-inner p { font-size: 13.5px; max-width: 380px; margin: 0; }
        .admin-link {
          margin-top: 14px;
          font-size: 12px;
          color: rgba(250,243,236,0.5);
        }
        .admin-link:hover { color: var(--soft-gold); }
      `}</style>
    </div>
  );
}
