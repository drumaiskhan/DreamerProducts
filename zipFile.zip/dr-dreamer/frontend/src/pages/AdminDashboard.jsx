import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../lib/api';
import ProductFormModal from '../components/ProductFormModal';

export default function AdminDashboard() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const navigate = useNavigate();

  function load() {
    setLoading(true);
    api.getAdminProducts()
      .then(setProducts)
      .catch((err) => {
        if (err.message.includes('authenticat') || err.message.includes('expired')) {
          localStorage.removeItem('dd_token');
          navigate('/admin/login');
        } else {
          setError(err.message);
        }
      })
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function handleDelete(product) {
    if (!confirm(`Remove "${product.name}"? This can't be undone.`)) return;
    try {
      await api.deleteProduct(product.id);
      load();
    } catch (err) {
      alert(err.message);
    }
  }

  function logout() {
    localStorage.removeItem('dd_token');
    navigate('/admin/login');
  }

  return (
    <div className="dash">
      <header className="dash-header">
        <div className="container dash-header-inner">
          <span className="display">Dr Dreamer — Admin</span>
          <div className="dash-header-actions">
            <a href="/" target="_blank" rel="noopener noreferrer" className="btn-ghost">View storefront</a>
            <button className="btn-ghost" onClick={logout}>Log out</button>
          </div>
        </div>
      </header>

      <main className="container dash-main">
        <div className="dash-toolbar">
          <h1 className="display">Products</h1>
          <button className="btn btn-primary" onClick={() => { setEditing(null); setFormOpen(true); }}>
            + Add product
          </button>
        </div>

        {loading && <p className="state-msg">Loading…</p>}
        {error && <p className="state-msg">{error}</p>}

        {!loading && !error && (
          products.length === 0 ? (
            <p className="state-msg">No products yet. Add your first one above.</p>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th></th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((p) => (
                    <tr key={p.id}>
                      <td>
                        {p.image_url ? (
                          <img className="thumb" src={`${api.base}${p.image_url}`} alt="" />
                        ) : (
                          <div className="thumb thumb-empty" />
                        )}
                      </td>
                      <td>
                        <span className="p-name">{p.name}</span>
                        {Boolean(p.featured) && <span className="badge">Featured</span>}
                      </td>
                      <td className="capitalize">{p.category}</td>
                      <td>Rs {Number(p.price).toLocaleString()}</td>
                      <td>{p.stock}</td>
                      <td className="row-actions">
                        <button className="btn-ghost" onClick={() => { setEditing(p); setFormOpen(true); }}>Edit</button>
                        <button className="btn-danger" onClick={() => handleDelete(p)}>Remove</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        )}
      </main>

      {formOpen && (
        <ProductFormModal
          product={editing}
          onClose={() => setFormOpen(false)}
          onSaved={() => { setFormOpen(false); load(); }}
        />
      )}

      <style>{`
        .dash { min-height: 100vh; background: var(--cream); }
        .dash-header {
          background: var(--twilight);
          color: var(--cream);
        }
        .dash-header-inner {
          display: flex;
          align-items: center;
          justify-content: space-between;
          height: 68px;
        }
        .dash-header .display { font-size: 19px; }
        .dash-header-actions { display: flex; gap: 8px; }
        .dash-header-actions .btn-ghost { color: rgba(250,243,236,0.75); }
        .dash-header-actions .btn-ghost:hover { color: #fff; }
        .dash-main { padding: 40px 28px 80px; }
        .dash-toolbar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 28px;
        }
        .dash-toolbar h1 { font-size: 26px; }
        .state-msg { color: var(--ink-soft); }
        .table-wrap {
          background: #fff;
          border-radius: var(--radius);
          border: 1px solid var(--border);
          overflow: hidden;
        }
        table { width: 100%; border-collapse: collapse; }
        thead th {
          text-align: left;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          color: var(--ink-soft);
          padding: 14px 18px;
          border-bottom: 1px solid var(--border);
        }
        tbody td {
          padding: 12px 18px;
          border-bottom: 1px solid var(--border);
          font-size: 14.5px;
          vertical-align: middle;
        }
        tbody tr:last-child td { border-bottom: none; }
        .thumb {
          width: 44px; height: 44px;
          border-radius: 8px;
          object-fit: cover;
        }
        .thumb-empty {
          background: linear-gradient(135deg, var(--moon-lavender), var(--dusty-rose));
          opacity: 0.4;
        }
        .p-name { font-weight: 600; }
        .badge {
          margin-left: 8px;
          font-size: 10.5px;
          font-weight: 700;
          color: #8A6A1E;
          background: #FBEBC7;
          padding: 2px 8px;
          border-radius: 999px;
        }
        .capitalize { text-transform: capitalize; }
        .row-actions { display: flex; gap: 8px; justify-content: flex-end; }
      `}</style>
    </div>
  );
}
