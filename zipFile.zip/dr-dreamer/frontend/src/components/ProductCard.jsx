import { api } from '../lib/api';

export default function ProductCard({ product, onEnquire }) {
  const imgSrc = product.image_url ? `${api.base}${product.image_url}` : null;

  return (
    <article className="card">
      <div className="card-image">
        {imgSrc ? (
          <img src={imgSrc} alt={product.name} />
        ) : (
          <div className="card-image-placeholder" aria-hidden="true" />
        )}
        <span className="card-tag">{product.category}</span>
      </div>
      <div className="card-body">
        <h3 className="card-name">{product.name}</h3>
        {product.description && <p className="card-desc">{product.description}</p>}
        <div className="card-footer">
          <span className="card-price">Rs {Number(product.price).toLocaleString()}</span>
          <button className="btn btn-outline card-btn" onClick={() => onEnquire(product)}>
            Enquire
          </button>
        </div>
      </div>

      <style>{`
        .card {
          background: #fff;
          border-radius: var(--radius);
          overflow: hidden;
          border: 1px solid var(--border);
          transition: box-shadow 0.2s ease, transform 0.2s ease;
        }
        .card:hover {
          box-shadow: var(--shadow);
          transform: translateY(-3px);
        }
        .card-image {
          position: relative;
          aspect-ratio: 1 / 1;
          background: linear-gradient(135deg, #F2E9E2, #EAD9DE);
        }
        .card-image img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        .card-image-placeholder {
          width: 100%;
          height: 100%;
          background: radial-gradient(circle at 40% 35%, var(--moon-lavender), transparent 60%),
                      radial-gradient(circle at 70% 70%, var(--dusty-rose), transparent 55%);
          opacity: 0.5;
        }
        .card-tag {
          position: absolute;
          top: 12px;
          left: 12px;
          background: rgba(255,255,255,0.9);
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.05em;
          text-transform: uppercase;
          padding: 5px 10px;
          border-radius: 999px;
          color: var(--ink-soft);
        }
        .card-body { padding: 18px 18px 20px; }
        .card-name {
          font-size: 18px;
          margin-bottom: 6px;
        }
        .card-desc {
          font-size: 13.5px;
          color: var(--ink-soft);
          line-height: 1.5;
          margin: 0 0 16px;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .card-footer {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
        .card-price {
          font-weight: 700;
          font-size: 15px;
        }
        .card-btn {
          padding: 9px 18px;
          font-size: 13px;
        }
      `}</style>
    </article>
  );
}
