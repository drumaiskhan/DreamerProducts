import { Link } from 'react-router-dom';

export default function Navbar({ active, onFilter }) {
  return (
    <header className="nav">
      <div className="container nav-inner">
        <Link to="/" className="nav-logo display">Dr Dreamer</Link>
        <nav className="nav-links">
          <button
            className={active === 'all' ? 'nav-link active' : 'nav-link'}
            onClick={() => onFilter('all')}
          >
            All
          </button>
          <button
            className={active === 'skin' ? 'nav-link active' : 'nav-link'}
            onClick={() => onFilter('skin')}
          >
            Skin
          </button>
          <button
            className={active === 'hair' ? 'nav-link active' : 'nav-link'}
            onClick={() => onFilter('hair')}
          >
            Hair
          </button>
        </nav>
      </div>

      <style>{`
        .nav {
          position: sticky;
          top: 0;
          z-index: 20;
          background: rgba(250, 243, 236, 0.86);
          backdrop-filter: blur(10px);
          border-bottom: 1px solid var(--border);
        }
        .nav-inner {
          display: flex;
          align-items: center;
          justify-content: space-between;
          height: 76px;
        }
        .nav-logo {
          font-size: 22px;
          font-weight: 500;
        }
        .nav-links {
          display: flex;
          gap: 6px;
        }
        .nav-link {
          background: none;
          border: none;
          font-size: 14px;
          font-weight: 600;
          color: var(--ink-soft);
          padding: 8px 16px;
          border-radius: 999px;
        }
        .nav-link.active {
          color: var(--ink);
          background: #fff;
          box-shadow: 0 2px 10px rgba(43,31,61,0.08);
        }
        .nav-link:hover { color: var(--ink); }
      `}</style>
    </header>
  );
}
