export default function Hero() {
  return (
    <section className="hero">
      <div className="blob" aria-hidden="true" />
      <div className="container hero-inner">
        <p className="eyebrow">SKIN &amp; HAIR CARE</p>
        <h1 className="display hero-title">
          The glow you keep <em>dreaming</em> about,<br /> now within reach.
        </h1>
        <p className="hero-sub">
          Small-batch formulas for skin and hair, made to be part of the quiet
          five minutes you get to yourself each day.
        </p>
        <a href="#shop" className="btn btn-primary">Browse products</a>
      </div>

      <style>{`
        .hero {
          position: relative;
          padding: 96px 0 80px;
          overflow: hidden;
        }
        .blob {
          position: absolute;
          top: -180px;
          right: -120px;
          width: 560px;
          height: 560px;
          border-radius: 50%;
          background: radial-gradient(circle at 30% 30%, var(--soft-gold), var(--dusty-rose) 45%, var(--moon-lavender) 80%);
          filter: blur(70px);
          opacity: 0.55;
          z-index: 0;
        }
        .hero-inner {
          position: relative;
          z-index: 1;
          max-width: 640px;
        }
        .eyebrow {
          font-size: 12.5px;
          font-weight: 700;
          letter-spacing: 0.14em;
          color: var(--dusty-rose);
          margin: 0 0 18px;
        }
        .hero-title {
          font-size: 46px;
          line-height: 1.15;
          margin-bottom: 22px;
        }
        .hero-title em {
          font-style: italic;
          color: var(--dusty-rose);
        }
        .hero-sub {
          font-size: 17px;
          line-height: 1.6;
          color: var(--ink-soft);
          margin-bottom: 32px;
          max-width: 460px;
        }
        @media (max-width: 640px) {
          .hero-title { font-size: 34px; }
          .blob { width: 380px; height: 380px; top: -120px; right: -140px; }
        }
      `}</style>
    </section>
  );
}
