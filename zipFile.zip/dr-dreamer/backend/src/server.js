import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

import db, { seedAdmin } from './db.js';
import { requireAdmin } from './authMiddleware.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const uploadsDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

seedAdmin(process.env.ADMIN_EMAIL, process.env.ADMIN_PASSWORD);

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(uploadsDir));

// --- Image upload setup ---
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const safeExt = ['.jpg', '.jpeg', '.png', '.webp'].includes(ext) ? ext : '.jpg';
    cb(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}${safeExt}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = ['image/jpeg', 'image/png', 'image/webp'].includes(file.mimetype);
    cb(ok ? null : new Error('Only JPG, PNG, or WEBP images are allowed'), ok);
  }
});

// ===================== AUTH =====================

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  const admin = db.prepare('SELECT * FROM admins WHERE email = ?').get(email);
  if (!admin || !bcrypt.compareSync(password, admin.password_hash)) {
    return res.status(401).json({ error: 'Incorrect email or password' });
  }

  const token = jwt.sign({ id: admin.id, email: admin.email }, process.env.JWT_SECRET, {
    expiresIn: '7d'
  });
  res.json({ token, email: admin.email });
});

// ===================== PUBLIC PRODUCT ROUTES =====================

app.get('/api/products', (req, res) => {
  const { category } = req.query;
  let rows;
  if (category === 'skin' || category === 'hair') {
    rows = db.prepare('SELECT * FROM products WHERE category = ? ORDER BY created_at DESC').all(category);
  } else {
    rows = db.prepare('SELECT * FROM products ORDER BY created_at DESC').all();
  }
  res.json(rows);
});

app.get('/api/products/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Product not found' });
  res.json(row);
});

// ===================== ADMIN PRODUCT ROUTES (protected) =====================

app.get('/api/admin/products', requireAdmin, (req, res) => {
  const rows = db.prepare('SELECT * FROM products ORDER BY created_at DESC').all();
  res.json(rows);
});

app.post('/api/admin/products', requireAdmin, upload.single('image'), (req, res) => {
  const { name, category, description, price, stock, featured } = req.body;

  if (!name || !category || !price) {
    return res.status(400).json({ error: 'Name, category, and price are required' });
  }
  if (!['skin', 'hair'].includes(category)) {
    return res.status(400).json({ error: 'Category must be "skin" or "hair"' });
  }

  const image_url = req.file ? `/uploads/${req.file.filename}` : null;

  const result = db.prepare(`
    INSERT INTO products (name, category, description, price, stock, image_url, featured)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    name,
    category,
    description || '',
    parseFloat(price),
    stock ? parseInt(stock, 10) : 0,
    image_url,
    featured === 'true' || featured === true ? 1 : 0
  );

  const created = db.prepare('SELECT * FROM products WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(created);
});

app.put('/api/admin/products/:id', requireAdmin, upload.single('image'), (req, res) => {
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Product not found' });

  const { name, category, description, price, stock, featured } = req.body;

  if (category && !['skin', 'hair'].includes(category)) {
    return res.status(400).json({ error: 'Category must be "skin" or "hair"' });
  }

  let image_url = existing.image_url;
  if (req.file) {
    // remove old image file if present
    if (existing.image_url) {
      const oldPath = path.join(uploadsDir, path.basename(existing.image_url));
      fs.unlink(oldPath, () => {});
    }
    image_url = `/uploads/${req.file.filename}`;
  }

  db.prepare(`
    UPDATE products
    SET name = ?, category = ?, description = ?, price = ?, stock = ?, image_url = ?, featured = ?
    WHERE id = ?
  `).run(
    name ?? existing.name,
    category ?? existing.category,
    description ?? existing.description,
    price !== undefined ? parseFloat(price) : existing.price,
    stock !== undefined ? parseInt(stock, 10) : existing.stock,
    image_url,
    featured !== undefined ? (featured === 'true' || featured === true ? 1 : 0) : existing.featured,
    req.params.id
  );

  const updated = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  res.json(updated);
});

app.delete('/api/admin/products/:id', requireAdmin, (req, res) => {
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Product not found' });

  if (existing.image_url) {
    const imgPath = path.join(uploadsDir, path.basename(existing.image_url));
    fs.unlink(imgPath, () => {});
  }

  db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// Friendly error handler for multer/file errors
app.use((err, req, res, next) => {
  if (err) {
    return res.status(400).json({ error: err.message || 'Something went wrong' });
  }
  next();
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Dr Dreamer API running on port ${PORT}`));
