# Dr Dreamer Products

A skin & hair care storefront with:
- A **public site** where customers browse products by category (Skin / Hair) and tap "Enquire" to message you on WhatsApp or email to order.
- A **password-protected admin panel** (only you can log in) to add, edit, and remove products — including uploading a product photo.

No online payments are wired up yet — enquiries go through WhatsApp/email so you can confirm orders manually. Stripe/PayPal can be added later if you want checkout on the site itself.

---

## Project structure

```
dr-dreamer/
├── backend/     Express + SQLite API (products, admin login, image upload)
└── frontend/    React storefront + admin dashboard
```

---

## 1. Run the backend

```bash
cd backend
npm install
npm start
```

This starts the API on **http://localhost:4000** and creates a `store.db` SQLite file automatically on first run, along with an admin account from `backend/.env`:

```
ADMIN_EMAIL=admin@drdreamer.com
ADMIN_PASSWORD=ChangeMe123!
```

**Before you go live:**
- Open `backend/.env` and change `ADMIN_PASSWORD` to something only you know, and change `JWT_SECRET` to a long random string.
- If you change the email/password *after* the admin account already exists in `store.db`, delete `store.db` (and `store.db-*` files) and restart the server so it re-seeds with the new credentials.

## 2. Run the frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

This opens the storefront at **http://localhost:5173**. The admin panel is at **http://localhost:5173/admin/login** (there's also a small "Admin" link in the storefront footer).

## 3. Before you launch this for real

Open `frontend/src/components/EnquiryModal.jsx` and update these two lines with your real contact details:

```js
const whatsappNumber = '923001234567'; // your WhatsApp number, country code, no +, no spaces
const contactEmail = 'hello@drdreamer.com';
```

## 4. Adding your products

Once both servers are running, go to `/admin/login`, sign in, and use **+ Add product** to add your skin/hair items with photos, prices, and stock counts. They'll appear on the storefront immediately.

## 5. Putting this online (so it's not just on your computer)

Right now this only runs on your machine. To make it a real public website you'll need to:
1. Deploy the `backend` folder to a Node host (e.g. Render, Railway, Fly.io).
2. Deploy the `frontend` folder to a static host (e.g. Vercel, Netlify) — set `VITE_API_URL` there to your deployed backend's URL.
3. Point your domain (e.g. drdreamerproducts.com) at the frontend deployment.

Happy to walk through any of these deployment steps whenever you're ready.
